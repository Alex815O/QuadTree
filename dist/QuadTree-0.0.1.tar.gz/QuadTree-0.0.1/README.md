# QuadTree

In this project I developed an simple QuadTree in Python.

If you executes QuadWindow.py a window will pop up which visualize the datastructure. 
I inmplementet a tiny command line too. Just enter some of the following commands and press enter. 

	- get x y
	returns the value which is stored at those coordinates
	
	- search value
	returns the coordinates of this value (only numbers)

	- pop x y
	removes the value at those coordinates
	
	- len
	returns the number of entries
	
(Please note that I created this small command line for testing purposes only) 

  
